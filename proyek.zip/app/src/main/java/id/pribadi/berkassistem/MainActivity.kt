package id.pribadi.berkassistem

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private class Aksi(
        val judul: String,
        val kartu: String,
        val ringkas: String,
        val ikon: Int,
        val chip: String?,
        val lanjutan: Boolean,
        val info: String,
        val pratinjau: () -> Unit,
        val hapus: (() -> Unit)?
    )

    private val daftarAksi = listOf(
        Aksi(
            judul = "1. Analisis penyimpanan",
            kartu = "Analisis penyimpanan",
            ringkas = "Aplikasi dan folder terbesar",
            ikon = R.drawable.ic_search,
            chip = "Hanya membaca",
            lanjutan = false,
            info = "Hanya membaca, tidak menghapus apa pun. Menampilkan aplikasi dengan data dan cache terbesar serta folder terbesar.",
            pratinjau = { analisis() },
            hapus = null
        ),
        Aksi(
            judul = "2. Bersihkan cache semua aplikasi",
            kartu = "Cache aplikasi",
            ringkas = "Semua aplikasi, cache saja",
            ikon = R.drawable.ic_box,
            chip = null,
            lanjutan = false,
            info = "Hanya cache (berkas sementara). Akun dan data aplikasi tidak dihapus, tetapi sebagian aplikasi atau game bisa mengunduh ulang aset. Log menampilkan cache tiap aplikasi sebelum dan sesudah.",
            pratinjau = { pratinjauCacheSemua() },
            hapus = { hapusCacheSemua() }
        ),
        Aksi(
            judul = "3. Bersihkan cache eksternal",
            kartu = "Cache eksternal",
            ringkas = "Folder cache di Android/data",
            ikon = R.drawable.ic_folder,
            chip = null,
            lanjutan = false,
            info = "Mengosongkan folder cache di /sdcard/Android/data/<aplikasi>/cache. Sebagian game menyimpan aset unduhan di cache; aset itu akan diunduh ulang. Log menampilkan tiap folder dan berkas di dalamnya.",
            pratinjau = { pratinjauCacheEksternal() },
            hapus = { hapusCacheEksternal() }
        ),
        Aksi(
            judul = "4. Bersihkan log MIUI",
            kartu = "Log MIUI",
            ringkas = "debug_log dan buffer logcat",
            ikon = R.drawable.ic_doc,
            chip = null,
            lanjutan = false,
            info = "Mengosongkan /sdcard/MIUI/debug_log dan /sdcard/MIUI/.debug_log, serta buffer logcat (buffer logcat ada di memori, jadi tidak menambah ruang).",
            pratinjau = { pratinjauLog() },
            hapus = { hapusLog() }
        ),
        Aksi(
            judul = "5. Reset dexopt",
            kartu = "Reset dexopt",
            ringkas = "Bisa beberapa menit. Aplikasi sempat terasa lebih lambat.",
            ikon = R.drawable.ic_chip,
            chip = "Lanjutan",
            lanjutan = true,
            info = "Mengembalikan hasil kompilasi aplikasi ke bawaan. Bisa beberapa menit, dan aplikasi mungkin terasa lebih lambat sampai sistem mengoptimalkan ulang. Tidak menghapus berkas pribadi.",
            pratinjau = { pratinjauDexopt() },
            hapus = { hapusDexopt() }
        )
    )

    private val kartuAlat = mutableListOf<View>()

    private lateinit var halamanBeranda: ScrollView
    private lateinit var halamanLog: LinearLayout
    private lateinit var scrollLog: ScrollView
    private lateinit var log: TextView
    private lateinit var judulLog: TextView
    private lateinit var progres: ProgressBar

    private lateinit var statusBox: FrameLayout
    private lateinit var statusJudul: TextView
    private lateinit var statusKet: TextView
    private lateinit var statusAksi: TextView
    private lateinit var bebasView: TextView

    private lateinit var actBox: FrameLayout
    private lateinit var actJudul: TextView
    private lateinit var actKet: TextView
    private lateinit var actSimpan: TextView
    private lateinit var actTombol: LinearLayout

    /** 0 siap, 1 belum berjalan, 2 izin belum diberikan, 3 tidak tersedia. */
    private var keadaanShizuku = 1

    private val listenerBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { segarkan() } }
    private val listenerMati = Shizuku.OnBinderDeadListener { runOnUiThread { segarkan() } }
    private val listenerIzin =
        Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { segarkan() } }

    private val pendengar = object : Sesi.Pendengar {
        override fun baris(teks: String) {
            log.append(teks + "\n")
            scrollLog.post { scrollLog.fullScroll(ScrollView.FOCUS_DOWN) }
        }

        override fun berubah() {
            segarkan()
            aturSibuk()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val frame = FrameLayout(this)
        frame.setBackgroundColor(T.BG)
        halamanBeranda = buatBeranda()
        halamanLog = buatHalamanLog()
        frame.addView(halamanBeranda, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        frame.addView(halamanLog, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        setContentView(frame)

        log.text = synchronized(Sesi.buffer) { Sesi.buffer.toString() }
        if (Sesi.logTerbuka) tampilLog(Sesi.judulLog) else tampilBeranda()

        Sesi.pendengar = pendengar
        Shizuku.addBinderReceivedListenerSticky(listenerBinder)
        Shizuku.addBinderDeadListener(listenerMati)
        Shizuku.addRequestPermissionResultListener(listenerIzin)
        segarkan()
        aturSibuk()
    }

    override fun onResume() {
        super.onResume()
        segarkan()
        aturSibuk()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(listenerBinder)
        Shizuku.removeBinderDeadListener(listenerMati)
        Shizuku.removeRequestPermissionResultListener(listenerIzin)
        if (Sesi.pendengar === pendengar) Sesi.pendengar = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (halamanLog.visibility == View.VISIBLE) tampilBeranda() else super.onBackPressed()
    }

    // ---------- tampilan ----------

    private fun buatBeranda(): ScrollView {
        val isi = LinearLayout(this)
        isi.orientation = LinearLayout.VERTICAL
        isi.setPadding(dp(16), dp(8), dp(16), dp(24))

        // bilah atas
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        val judulKol = LinearLayout(this)
        judulKol.orientation = LinearLayout.VERTICAL
        judulKol.addView(Ui.teks(this, "RuangLega", 22f, T.T1, true))
        judulKol.addView(Ui.teks(this, "Android Utility Center", 12f, T.T2))
        bar.addView(judulKol, Ui.lp(this, 0, Ui.WRAP, 1f))
        bar.addView(
            Ui.tombolIkon(this, R.drawable.ic_doc, "Lihat log") { tampilLog("Log aktivitas") },
            Ui.lp(this, dp(48), dp(48))
        )
        isi.addView(bar, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0f, 0, 8, 0, 12))

        // kartu status
        val ks = Ui.kartu(this)
        val barisStatus = LinearLayout(this)
        barisStatus.orientation = LinearLayout.HORIZONTAL
        barisStatus.gravity = Gravity.CENTER_VERTICAL
        statusBox = Ui.kotakIkon(this)
        barisStatus.addView(statusBox, Ui.lp(this, dp(40), dp(40)))
        val kolStatus = LinearLayout(this)
        kolStatus.orientation = LinearLayout.VERTICAL
        statusJudul = Ui.teks(this, "", 15f, T.T1, true)
        statusKet = Ui.teks(this, "", 12f, T.T2)
        kolStatus.addView(statusJudul)
        kolStatus.addView(statusKet, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0f, 0, 2, 0, 0))
        barisStatus.addView(kolStatus, Ui.lp(this, 0, Ui.WRAP, 1f, 12, 0, 0, 0))
        ks.addView(barisStatus)
        statusAksi = Ui.tombol(this, "Buka Shizuku", true) {
            if (keadaanShizuku == 2) mintaIzin() else bukaShizuku()
        }
        ks.addView(statusAksi, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0f, 0, 12, 0, 0))
        ks.addView(Ui.garis(this), Ui.lp(this, Ui.MATCH, 1, 0f, 0, 12, 0, 12))
        val barisBebas = LinearLayout(this)
        barisBebas.orientation = LinearLayout.HORIZONTAL
        barisBebas.addView(Ui.teks(this, "Ruang bebas", 14f, T.T2), Ui.lp(this, 0, Ui.WRAP, 1f))
        bebasView = Ui.teks(this, "", 14f, T.T1, true)
        barisBebas.addView(bebasView)
        ks.addView(barisBebas)
        isi.addView(ks)

        // alat pemeliharaan
        isi.addView(Ui.bagian(this, "Alat pemeliharaan"), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0f, 0, 20, 0, 10))
        kartuAlat.clear()
        for (m in 0..1) {
            val baris = LinearLayout(this)
            baris.orientation = LinearLayout.HORIZONTAL
            baris.isBaselineAligned = false
            val kiri = buatKartuAlat(daftarAksi[m * 2])
            val kanan = buatKartuAlat(daftarAksi[m * 2 + 1])
            baris.addView(kiri, Ui.lp(this, 0, Ui.MATCH, 1f, 0, 0, 5, 0))
            baris.addView(kanan, Ui.lp(this, 0, Ui.MATCH, 1f, 5, 0, 0, 0))
            isi.addView(baris, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, 10))
        }

        // pemeliharaan lanjutan
        isi.addView(Ui.bagian(this, "Pemeliharaan lanjutan"), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0f, 0, 10, 0, 10))
        isi.addView(buatKartuLanjutan(daftarAksi[4]))

        // aktivitas
        isi.addView(Ui.bagian(this, "Aktivitas terakhir"), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0f, 0, 20, 0, 10))
        val ka = Ui.kartu(this)
        val barisAkt = LinearLayout(this)
        barisAkt.orientation = LinearLayout.HORIZONTAL
        barisAkt.gravity = Gravity.CENTER_VERTICAL
        actBox = Ui.kotakIkon(this)
        barisAkt.addView(actBox, Ui.lp(this, dp(40), dp(40)))
        val kolAkt = LinearLayout(this)
        kolAkt.orientation = LinearLayout.VERTICAL
        actJudul = Ui.teks(this, "", 15f, T.T1, true)
        actKet = Ui.teks(this, "", 12f, T.T2)
        kolAkt.addView(actJudul)
        kolAkt.addView(actKet, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0f, 0, 2, 0, 0))
        barisAkt.addView(kolAkt, Ui.lp(this, 0, Ui.WRAP, 1f, 12, 0, 0, 0))
        ka.addView(barisAkt)
        actSimpan = Ui.teks(this, "", 12f, T.T2)
        ka.addView(actSimpan, Ui.lp(this, Ui.WRAP, Ui.WRAP, 0f, 0, 12, 0, 0))
        actTombol = LinearLayout(this)
        actTombol.orientation = LinearLayout.HORIZONTAL
        actTombol.addView(
            Ui.tombol(this, "Lihat log", false) { tampilLog("Log aktivitas") },
            Ui.lp(this, 0, Ui.WRAP, 1f, 0, 0, 5, 0)
        )
        actTombol.addView(
            Ui.tombol(this, "Salin log", false) { salinLog() },
            Ui.lp(this, 0, Ui.WRAP, 1f, 5, 0, 0, 0)
        )
        ka.addView(actTombol, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0f, 0, 12, 0, 0))
        isi.addView(ka)

        val sv = ScrollView(this)
        sv.setBackgroundColor(T.BG)
        sv.addView(isi, ScrollView.LayoutParams(Ui.MATCH, Ui.WRAP))
        return sv
    }

    private fun buatKartuAlat(aksi: Aksi): LinearLayout {
        val k = Ui.kartu(this)
        Ui.kartuKlik(this, k) { klik(aksi) }
        k.minimumHeight = dp(132)
        val kotak = Ui.kotakIkon(this)
        Ui.aturKotak(this, kotak, aksi.ikon, T.PR)
        k.addView(kotak, Ui.lp(this, dp(40), dp(40)))
        k.addView(Ui.teks(this, aksi.kartu, 15f, T.T1, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0f, 0, 8, 0, 0))
        k.addView(Ui.teks(this, aksi.ringkas, 12f, T.T2), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0f, 0, 2, 0, 0))
        if (aksi.chip != null) {
            k.addView(Ui.chip(this, aksi.chip, T.PR), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0f, 0, 6, 0, 0))
        }
        kartuAlat.add(k)
        return k
    }

    private fun buatKartuLanjutan(aksi: Aksi): LinearLayout {
        val k = Ui.kartu(this)
        Ui.kartuKlik(this, k) { klik(aksi) }
        k.orientation = LinearLayout.HORIZONTAL
        k.gravity = Gravity.CENTER_VERTICAL
        val kotak = Ui.kotakIkon(this)
        Ui.aturKotak(this, kotak, aksi.ikon, T.WR)
        k.addView(kotak, Ui.lp(this, dp(40), dp(40)))
        val kol = LinearLayout(this)
        kol.orientation = LinearLayout.VERTICAL
        kol.addView(Ui.teks(this, aksi.kartu, 15f, T.T1, true))
        kol.addView(Ui.teks(this, aksi.ringkas, 12f, T.T2), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0f, 0, 2, 0, 0))
        if (aksi.chip != null) {
            kol.addView(Ui.chip(this, aksi.chip, T.WR), Ui.lp(this, Ui.WRAP, Ui.WRAP, 0f, 0, 6, 0, 0))
        }
        k.addView(kol, Ui.lp(this, 0, Ui.WRAP, 1f, 12, 0, 0, 0))
        kartuAlat.add(k)
        return k
    }

    private fun buatHalamanLog(): LinearLayout {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.VERTICAL
        h.setBackgroundColor(T.BG)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(8), dp(8), dp(8), dp(8))
        bar.addView(
            Ui.tombolIkon(this, R.drawable.ic_back, "Kembali") { tampilBeranda() },
            Ui.lp(this, dp(48), dp(48))
        )
        judulLog = Ui.teks(this, "Log aktivitas", 18f, T.T1, true)
        bar.addView(judulLog, Ui.lp(this, 0, Ui.WRAP, 1f, 8, 0, 8, 0))
        bar.addView(
            Ui.tombolIkon(this, R.drawable.ic_copy, "Salin seluruh log") { salinLog() },
            Ui.lp(this, dp(48), dp(48))
        )
        h.addView(bar)

        progres = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progres.isIndeterminate = true
        progres.indeterminateTintList = ColorStateList.valueOf(T.PR)
        progres.visibility = View.INVISIBLE
        h.addView(progres, Ui.lp(this, Ui.MATCH, dp(4)))

        log = TextView(this)
        log.typeface = Typeface.MONOSPACE
        log.textSize = 12f
        log.setTextColor(T.T1)
        log.setTextIsSelectable(true)
        log.setPadding(dp(16), dp(12), dp(16), dp(24))
        scrollLog = ScrollView(this)
        scrollLog.addView(log)
        h.addView(scrollLog, Ui.lp(this, Ui.MATCH, 0, 1f))
        return h
    }

    private fun tampilLog(judul: String) {
        judulLog.text = judul
        Sesi.logTerbuka = true
        Sesi.judulLog = judul
        halamanBeranda.visibility = View.GONE
        halamanLog.visibility = View.VISIBLE
        scrollLog.post { scrollLog.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun tampilBeranda() {
        Sesi.logTerbuka = false
        halamanLog.visibility = View.GONE
        halamanBeranda.visibility = View.VISIBLE
        segarkan()
    }

    private fun aturSibuk() {
        val s = Sesi.sibuk
        kartuAlat.forEach {
            it.isEnabled = !s
            it.alpha = if (s) 0.5f else 1f
        }
        progres.visibility = if (s) View.VISIBLE else View.INVISIBLE
    }

    // ---------- util ----------

    private fun dp(nilai: Int): Int = Ui.dp(this, nilai)

    private fun fmt(byte: Long): String = Formatter.formatFileSize(applicationContext, byte)

    private fun bebasByte(): Long =
        StatFs(Environment.getDataDirectory().path).availableBytes

    private fun sh(perintah: String): Shell.Hasil = try {
        Shell.jalankan(perintah)
    } catch (e: Throwable) {
        val sebab = e.cause ?: e
        Shell.Hasil(-1, "", sebab.javaClass.simpleName + ": " + sebab.message)
    }

    /** Masuk ke berkas log dan tampil di layar log. */
    private fun catat(teks: String) {
        val baris = synchronized(Sesi.buffer) {
            val b = if (teks.isEmpty()) "" else Sesi.jam.format(Date()) + "  " + teks
            Sesi.buffer.append(b).append('\n')
            b
        }
        Sesi.kirimBaris(baris)
    }

    /** Hanya masuk ke berkas log (rincian panjang), tidak ditampilkan di layar. */
    private fun catatFile(teks: String) {
        synchronized(Sesi.buffer) { Sesi.buffer.append("          ").append(teks).append('\n') }
    }

    /** Pesan singkat untuk pengguna di beranda: toast dan juga masuk log. */
    private fun info(teks: String) {
        catat(teks)
        runOnUiThread { Toast.makeText(this, teks, Toast.LENGTH_LONG).show() }
    }

    // ---------- status ----------

    private fun segarkan() {
        keadaanShizuku = try {
            when {
                !Shizuku.pingBinder() -> 1
                Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> 2
                else -> 0
            }
        } catch (e: Throwable) {
            3
        }
        when (keadaanShizuku) {
            0 -> {
                Ui.aturKotak(this, statusBox, R.drawable.ic_check, T.OK)
                statusJudul.text = "Shizuku aktif dan siap"
                statusKet.text = "Layanan berjalan, izin diberikan"
                statusAksi.visibility = View.GONE
            }
            1 -> {
                Ui.aturKotak(this, statusBox, R.drawable.ic_warn, T.WR)
                statusJudul.text = "Shizuku belum berjalan"
                statusKet.text = "Buka Shizuku lalu mulai lewat Wireless debugging"
                statusAksi.text = "Buka Shizuku"
                statusAksi.visibility = View.VISIBLE
            }
            2 -> {
                Ui.aturKotak(this, statusBox, R.drawable.ic_warn, T.WR)
                statusJudul.text = "Izin belum diberikan"
                statusKet.text = "Shizuku berjalan, tetapi aplikasi ini belum diizinkan"
                statusAksi.text = "Beri izin Shizuku"
                statusAksi.visibility = View.VISIBLE
            }
            else -> {
                Ui.aturKotak(this, statusBox, R.drawable.ic_x, T.DG)
                statusJudul.text = "Shizuku tidak tersedia"
                statusKet.text = "Terjadi kesalahan membaca layanan. Pasang atau buka Shizuku."
                statusAksi.text = "Buka Shizuku"
                statusAksi.visibility = View.VISIBLE
            }
        }
        bebasView.text = fmt(bebasByte())
        segarkanAktivitas()
    }

    private fun segarkanAktivitas() {
        if (Sesi.terakhirJudul.isEmpty()) {
            Ui.aturKotak(this, actBox, R.drawable.ic_doc, T.T2)
            actJudul.text = "Belum ada aktivitas"
            actKet.text = "Hasil operasi akan muncul di sini."
            actSimpan.visibility = View.GONE
            actTombol.visibility = View.GONE
            return
        }
        val (ikon, warna) = when (Sesi.terakhirHasil) {
            "Selesai" -> Pair(R.drawable.ic_check, T.OK)
            "Gagal" -> Pair(R.drawable.ic_x, T.DG)
            else -> Pair(R.drawable.ic_doc, T.PR)
        }
        Ui.aturKotak(this, actBox, ikon, warna)
        actJudul.text = Sesi.terakhirJudul
        val ring = Sesi.terakhirRingkas
        actKet.text = Sesi.terakhirWaktu + " · " + Sesi.terakhirHasil +
            (if (ring.isNotEmpty()) " · " + ring else "")
        val p = Sesi.logTersimpan
        if (p != null) {
            actSimpan.text = "Tersimpan: " + p.removePrefix("/sdcard/")
            actSimpan.visibility = View.VISIBLE
        } else {
            actSimpan.visibility = View.GONE
        }
        actTombol.visibility = View.VISIBLE
    }

    private fun siap(): Boolean = try {
        Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    private fun bukaShizuku() {
        val intent = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (intent == null) {
            info("Aplikasi Shizuku belum terpasang. Pasang dulu dari GitHub atau Play Store.")
        } else {
            startActivity(intent)
        }
    }

    private fun mintaIzin() {
        try {
            if (!Shizuku.pingBinder()) {
                info("Shizuku belum berjalan. Buka aplikasi Shizuku lalu mulai lewat Wireless debugging.")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                info("Izin sudah diberikan.")
                return
            }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                info("Izin ditolak permanen. Aktifkan lewat aplikasi Shizuku, menu izin aplikasi.")
                return
            }
            Shizuku.requestPermission(100)
        } catch (e: Throwable) {
            info("Gagal meminta izin: " + e.message)
        }
    }

    private fun salinLog() {
        val isi = synchronized(Sesi.buffer) { Sesi.buffer.toString() }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("log", isi))
        Toast.makeText(this, "Log disalin", Toast.LENGTH_SHORT).show()
    }

    private fun simpanLog() {
        try {
            val dir = applicationContext.getExternalFilesDir(null) ?: applicationContext.filesDir
            val sementara = File(dir, "log.tmp")
            val isi = synchronized(Sesi.buffer) { Sesi.buffer.toString() }
            sementara.writeText(isi)
            val tujuan = "/sdcard/Download/" + Sesi.namaLog
            val r = sh("cp '" + sementara.absolutePath + "' '" + tujuan + "'")
            if (r.kode == 0) {
                Sesi.logTersimpan = tujuan
                catat("Log lengkap disimpan: " + tujuan)
            } else {
                Sesi.logTersimpan = null
                catat("Log tidak bisa disimpan ke Download (" + r.err + "). Pakai tombol Salin seluruh log.")
            }
        } catch (e: Throwable) {
            Sesi.logTersimpan = null
            catat("Log tidak bisa disimpan: " + e.message)
        }
    }

    // ---------- alur tombol ----------

    private fun klik(aksi: Aksi) {
        if (Sesi.sibuk) {
            Toast.makeText(this, "Operasi masih berjalan", Toast.LENGTH_SHORT).show()
            return
        }
        if (!siap()) {
            info("Shizuku belum siap. Pastikan Shizuku berjalan dan izin sudah diberikan.")
            return
        }
        val hapus = aksi.hapus
        if (hapus == null) {
            kerjakan(aksi.judul, aksi.pratinjau)
            return
        }
        AlertDialog.Builder(this)
            .setTitle(aksi.judul)
            .setMessage(aksi.info + "\n\n\"Pratinjau saja\" hanya menampilkan apa yang akan dihapus, tanpa menghapus.")
            .setPositiveButton("Hapus") { _, _ -> kerjakan(aksi.judul, hapus) }
            .setNeutralButton("Pratinjau saja") { _, _ ->
                kerjakan("Pratinjau (tidak ada yang dihapus): " + aksi.judul, aksi.pratinjau)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun kerjakan(judul: String, kerja: () -> Unit) {
        if (Sesi.sibuk) return
        Sesi.sibuk = true
        Sesi.terakhirJudul = judul
        Sesi.terakhirWaktu = SimpleDateFormat("HH:mm", Locale.US).format(Date())
        Sesi.terakhirHasil = "Berjalan"
        Sesi.terakhirRingkas = ""
        Sesi.logTersimpan = null
        catat("")
        catat("> " + judul)
        tampilLog(judul)
        aturSibuk()
        Sesi.executor.execute {
            val sebelum = bebasByte()
            var gagal = false
            try {
                kerja()
            } catch (e: Throwable) {
                gagal = true
                catat("GAGAL: " + e.javaClass.simpleName + ": " + e.message)
            }
            val sesudah = bebasByte()
            catat("Ruang bebas: " + fmt(sebelum) + " -> " + fmt(sesudah))
            Sesi.terakhirRingkas = "Ruang bebas " + fmt(sebelum) + " → " + fmt(sesudah)
            Sesi.terakhirHasil = if (gagal) "Gagal" else "Selesai"
            simpanLog()
            Sesi.sibuk = false
            Sesi.beritahu()
        }
    }

    // ---------- statistik aplikasi ----------

    private fun ambilPaket(): List<Stat.Paket> {
        sh("appops set " + packageName + " GET_USAGE_STATS allow")
        val p = try {
            Stat.ambil(applicationContext)
        } catch (e: Throwable) {
            catat("Statistik aplikasi tidak terbaca: " + e.javaClass.simpleName + ": " + e.message)
            emptyList()
        }
        if (p.isEmpty()) catat("Tidak ada data aplikasi yang terbaca.")
        return p
    }

    private fun tampil(urut: List<Stat.Paket>, batas: Int, nilai: (Stat.Paket) -> Long) {
        var i = 0
        for (x in urut) {
            val n = nilai(x)
            if (n <= 0) continue
            val baris = fmt(n).padStart(10) + "  " + x.label + " (" + x.nama + ")"
            if (i < batas) catat(baris) else catatFile(baris)
            i++
        }
        if (i > batas) catat("... " + (i - batas) + " aplikasi lain ada di berkas log")
    }

    // ---------- 1. analisis ----------

    private fun analisis() {
        val p = ambilPaket()
        if (p.isNotEmpty()) {
            catat("Aplikasi terbaca: " + p.size)
            catat("Kode aplikasi total: " + fmt(p.sumOf { it.app }))
            catat("Data aplikasi total (di luar cache): " + fmt(p.sumOf { it.data - it.cache }))
            catat("Cache aplikasi total: " + fmt(p.sumOf { it.cache }))
            catat("-- Data terbesar (di luar cache) --")
            tampil(p.sortedByDescending { it.data - it.cache }, 15) { it.data - it.cache }
            catat("-- Cache terbesar --")
            tampil(p.sortedByDescending { it.cache }, 15) { it.cache }
        }
        catat("-- Folder Android/data terbesar --")
        val d = sh("du -sm /sdcard/Android/data/* 2>/dev/null | sort -rn | head -n 15")
        d.out.lines().forEach { if (it.isNotBlank()) catat(it) }
        catat("-- Folder tersembunyi di /sdcard (MB) --")
        val h = sh("du -sm /sdcard/.[!.]* 2>/dev/null | sort -rn | head -n 10")
        h.out.lines().forEach { if (it.isNotBlank()) catat(it) }
        catat("-- Sisa ruang /data --")
        catat(sh("df -h /data | tail -n 1").out)
    }

    // ---------- 2. cache semua aplikasi ----------

    private fun pratinjauCacheSemua() {
        val p = ambilPaket()
        if (p.isEmpty()) return
        val ada = p.filter { it.cache > 0 }.sortedByDescending { it.cache }
        catat("Cache yang AKAN dihapus: " + fmt(ada.sumOf { it.cache }) + " dari " + ada.size + " aplikasi")
        catat("(Hanya cache. Akun dan data aplikasi tidak dihapus; sebagian aplikasi bisa mengunduh ulang aset.)")
        tampil(ada, 30) { it.cache }
    }

    private fun hapusCacheSemua() {
        val sebelum = ambilPaket()
        if (sebelum.isEmpty()) return
        catat("Total cache sebelum: " + fmt(sebelum.sumOf { it.cache }))
        val r = sh("pm trim-caches 999G")
        catat("pm trim-caches selesai, kode " + r.kode + (if (r.err.isNotEmpty()) " [" + r.err + "]" else ""))
        val sesudah = ambilPaket().associateBy { it.nama }
        val turun = sebelum
            .map { Pair(it, it.cache - (sesudah[it.nama]?.cache ?: it.cache)) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
        catat("Cache yang benar-benar terhapus: " + fmt(turun.sumOf { it.second }) + " dari " + turun.size + " aplikasi")
        var i = 0
        for (h in turun) {
            val baris = fmt(h.second).padStart(10) + "  " + h.first.label + " (" + h.first.nama + ")"
            if (i < 30) catat(baris) else catatFile(baris)
            i++
        }
        if (turun.size > 30) catat("... " + (turun.size - 30) + " aplikasi lain ada di berkas log")
        catat("Total cache sesudah: " + fmt(sesudah.values.sumOf { it.cache }))
    }

    // ---------- 3. cache eksternal ----------

    private fun ukuranKb(path: String): Long {
        val out = sh("du -sk '" + path + "' 2>/dev/null").out
        return out.trim().split(Regex("\\s+")).firstOrNull()?.toLongOrNull() ?: 0L
    }

    private fun foldersBerisi(perintahDaftar: String): List<Pair<String, Long>> {
        val dirs = sh(perintahDaftar).out.lines().filter { it.startsWith("/") }
        return dirs.map { Pair(it, ukuranKb(it)) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
    }

    private fun catatBerkas(path: String) {
        val daftar = sh("find '" + path + "' -type f 2>/dev/null").out.lines().filter { it.isNotBlank() }
        daftar.take(300).forEach { catatFile("  - " + it) }
        if (daftar.size > 300) catatFile("  ... dan " + (daftar.size - 300) + " berkas lain")
    }

    private fun pratinjauCacheEksternal() {
        val d = foldersBerisi("ls -d /sdcard/Android/data/*/cache 2>/dev/null")
        catat("Folder yang AKAN dikosongkan: " + d.size + ", total " + fmt(d.sumOf { it.second } * 1024))
        var i = 0
        for (x in d) {
            val baris = fmt(x.second * 1024).padStart(10) + "  " + x.first
            if (i < 30) catat(baris) else catatFile(baris)
            catatBerkas(x.first)
            i++
        }
        if (d.size > 30) catat("... " + (d.size - 30) + " folder lain ada di berkas log")
    }

    private fun hapusCacheEksternal() {
        val d = foldersBerisi("ls -d /sdcard/Android/data/*/cache 2>/dev/null")
        catat("Mengosongkan " + d.size + " folder, total " + fmt(d.sumOf { it.second } * 1024))
        var i = 0
        for (x in d) {
            catatBerkas(x.first)
            sh("rm -rf '" + x.first + "'/* '" + x.first + "'/.[!.]* 2>/dev/null")
            val sisa = ukuranKb(x.first)
            val baris = "dihapus " + fmt(x.second * 1024).padStart(10) + "  " + x.first +
                (if (sisa > 0) "  (sisa " + fmt(sisa * 1024) + ")" else "")
            if (i < 30) catat(baris) else catatFile(baris)
            i++
        }
        if (d.size > 30) catat("... " + (d.size - 30) + " folder lain ada di berkas log")
    }

    // ---------- 4. log MIUI ----------

    private val folderLog = "ls -d /sdcard/MIUI/debug_log /sdcard/MIUI/.debug_log 2>/dev/null"

    private fun pratinjauLog() {
        val d = foldersBerisi(folderLog)
        if (d.isEmpty()) catat("Folder log MIUI kosong atau tidak ada, tidak ada yang akan dihapus.")
        for (x in d) {
            catat("AKAN dikosongkan: " + fmt(x.second * 1024).padStart(10) + "  " + x.first)
            catatBerkas(x.first)
        }
        catat("Buffer logcat saat ini:")
        sh("logcat -g 2>&1").out.lines().take(10).forEach { catat(it) }
    }

    private fun hapusLog() {
        val d = foldersBerisi(folderLog)
        for (x in d) {
            catatBerkas(x.first)
            sh("rm -rf '" + x.first + "'/* '" + x.first + "'/.[!.]* 2>/dev/null")
            catat("dihapus " + fmt(x.second * 1024).padStart(10) + "  " + x.first)
        }
        if (d.isEmpty()) catat("Folder log MIUI kosong atau tidak ada.")
        val r = sh("logcat -b all -c")
        catat("Buffer logcat dikosongkan, kode " + r.kode)
    }

    // ---------- 5. dexopt ----------

    private fun pratinjauDexopt() {
        val p = ambilPaket()
        if (p.isEmpty()) return
        catat("Kode aplikasi total saat ini: " + fmt(p.sumOf { it.app }))
        catat("Reset dexopt tidak menghapus berkas apa pun milikmu; hanya hasil kompilasi (oat/odex) yang dibuat ulang.")
        catat("Aplikasi dengan ukuran kode terbesar:")
        tampil(p.sortedByDescending { it.app }, 15) { it.app }
    }

    private fun hapusDexopt() {
        val sebelum = ambilPaket()
        if (sebelum.isEmpty()) return
        val a0 = sebelum.sumOf { it.app }
        catat("Kode aplikasi total sebelum: " + fmt(a0))
        catat("Menjalankan reset dexopt, mohon tunggu...")
        val r = sh("cmd package compile --reset -a")
        val baris = r.out.lines().filter { it.isNotBlank() }
        catat("Selesai, kode " + r.kode + ", " + baris.size + " baris keluaran")
        baris.take(5).forEach { catat(it) }
        baris.drop(5).forEach { catatFile(it) }
        if (r.err.isNotEmpty()) catat("[stderr] " + r.err)
        val a1 = ambilPaket().sumOf { it.app }
        catat("Kode aplikasi total sesudah: " + fmt(a1))
        catat(if (a1 <= a0) "Turun " + fmt(a0 - a1) else "Naik " + fmt(a1 - a0))
    }
}
