package id.pribadi.berkassistem

import android.os.Handler
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Keadaan yang harus bertahan saat Activity dibuat ulang (rotasi, ukuran font, tema):
 * log, status sibuk, dan hasil operasi terakhir. Tampilan hanya mengikat diri ke objek ini.
 */
object Sesi {

    interface Pendengar {
        fun baris(teks: String)
        fun berubah()
    }

    val executor: ExecutorService = Executors.newSingleThreadExecutor()
    val buffer = StringBuilder()
    val jam = SimpleDateFormat("HH:mm:ss", Locale.US)
    val namaLog: String =
        "RuangLega-log-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".txt"

    @Volatile var sibuk = false
    @Volatile var terakhirJudul = ""
    @Volatile var terakhirWaktu = ""
    @Volatile var terakhirHasil = ""
    @Volatile var terakhirRingkas = ""

    /** Terisi hanya setelah berkas log benar-benar berhasil dibuat di Download. */
    @Volatile var logTersimpan: String? = null

    @Volatile var logTerbuka = false
    @Volatile var judulLog = "Log aktivitas"
    @Volatile var pendengar: Pendengar? = null

    private val main = Handler(Looper.getMainLooper())

    fun kirimBaris(b: String) {
        main.post { pendengar?.baris(b) }
    }

    fun beritahu() {
        main.post { pendengar?.berubah() }
    }
}
