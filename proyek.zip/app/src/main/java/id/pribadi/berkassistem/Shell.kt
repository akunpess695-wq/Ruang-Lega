package id.pribadi.berkassistem

import rikka.shizuku.Shizuku

/**
 * Menjalankan perintah shell lewat Shizuku (hak akses shell/ADB).
 *
 * Shizuku.newProcess bersifat private di API 13.x, jadi dipanggil lewat refleksi.
 */
object Shell {

    data class Hasil(val kode: Int, val out: String, val err: String)

    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    fun jalankan(perintah: String): Hasil {
        val proses = newProcess.invoke(null, arrayOf("sh", "-c", perintah), null, null) as Process
        var err = ""
        val pembacaErr = Thread { err = proses.errorStream.bufferedReader().readText() }
        pembacaErr.start()
        val out = proses.inputStream.bufferedReader().readText()
        pembacaErr.join()
        val kode = proses.waitFor()
        return Hasil(kode, out.trim(), err.trim())
    }
}
