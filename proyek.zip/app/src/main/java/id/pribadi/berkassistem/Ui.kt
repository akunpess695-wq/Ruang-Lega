package id.pribadi.berkassistem

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Token warna (sesuai brief UI/UX). */
object T {
    val BG = 0xFF101319.toInt()
    val SF = 0xFF1B202A.toInt()
    val SE = 0xFF232A36.toInt()
    val PR = 0xFF438BFF.toInt()
    val OK = 0xFF36C98F.toInt()
    val WR = 0xFFFFB547.toInt()
    val DG = 0xFFFF626C.toInt()
    val T1 = 0xFFF4F6FA.toInt()
    val T2 = 0xFF9BA5B5.toInt()
    val DV = 0xFF343B48.toInt()
    val ON_PR = 0xFF0B1020.toInt()
}

/** Komponen kecil yang dipakai ulang. Semua ukuran dalam dp/sp. */
object Ui {
    val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun alfa(warna: Int, persen: Int = 16): Int =
        (warna and 0x00FFFFFF) or ((255 * persen / 100) shl 24)

    fun bentuk(c: Context, warna: Int, radiusDp: Int, garis: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(warna)
        g.cornerRadius = dp(c, radiusDp).toFloat()
        if (garis != 0) g.setStroke(dp(c, 1), garis)
        return g
    }

    fun riak(c: Context, isi: Drawable, radiusDp: Int): Drawable {
        val mask = GradientDrawable()
        mask.setColor(Color.BLACK)
        mask.cornerRadius = dp(c, radiusDp).toFloat()
        return RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), isi, mask)
    }

    fun teks(c: Context, s: String, sp: Float, warna: Int, medium: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.textSize = sp
        t.setTextColor(warna)
        if (medium) t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        return t
    }

    fun lp(
        c: Context, w: Int, h: Int, bobot: Float = 0f,
        kiri: Int = 0, atas: Int = 0, kanan: Int = 0, bawah: Int = 0
    ): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, bobot)
        p.setMargins(dp(c, kiri), dp(c, atas), dp(c, kanan), dp(c, bawah))
        return p
    }

    fun kartu(c: Context): LinearLayout {
        val k = LinearLayout(c)
        k.orientation = LinearLayout.VERTICAL
        val p = dp(c, 14)
        k.setPadding(p, p, p, p)
        k.background = bentuk(c, T.SF, 16, T.DV)
        return k
    }

    fun kartuKlik(c: Context, k: View, aksi: () -> Unit) {
        k.background = riak(c, bentuk(c, T.SF, 16, T.DV), 16)
        k.isClickable = true
        k.isFocusable = true
        k.setOnClickListener { aksi() }
    }

    fun kotakIkon(c: Context): FrameLayout {
        val f = FrameLayout(c)
        val iv = ImageView(c)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        f.addView(iv, FrameLayout.LayoutParams(dp(c, 22), dp(c, 22), Gravity.CENTER))
        return f
    }

    fun aturKotak(c: Context, f: FrameLayout, res: Int, warna: Int) {
        f.background = bentuk(c, alfa(warna), 12)
        val iv = f.getChildAt(0) as ImageView
        iv.setImageResource(res)
        iv.setColorFilter(warna, PorterDuff.Mode.SRC_IN)
    }

    fun chip(c: Context, s: String, warna: Int): TextView {
        val t = teks(c, s, 11f, warna)
        t.setPadding(dp(c, 8), dp(c, 2), dp(c, 8), dp(c, 2))
        t.background = bentuk(c, alfa(warna), 8)
        return t
    }

    fun tombol(c: Context, label: String, isi: Boolean, aksi: () -> Unit): TextView {
        val t = teks(c, label, 14f, if (isi) T.ON_PR else T.T1, true)
        t.gravity = Gravity.CENTER
        t.minHeight = dp(c, 48)
        t.setPadding(dp(c, 16), 0, dp(c, 16), 0)
        val dasar = if (isi) bentuk(c, T.PR, 12) else bentuk(c, Color.TRANSPARENT, 12, T.DV)
        t.background = riak(c, dasar, 12)
        t.isClickable = true
        t.isFocusable = true
        t.setOnClickListener { aksi() }
        return t
    }

    fun tombolIkon(c: Context, res: Int, deskripsi: String, aksi: () -> Unit): FrameLayout {
        val f = FrameLayout(c)
        val iv = ImageView(c)
        iv.setImageResource(res)
        iv.setColorFilter(T.T1, PorterDuff.Mode.SRC_IN)
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        f.addView(iv, FrameLayout.LayoutParams(dp(c, 22), dp(c, 22), Gravity.CENTER))
        f.background = riak(c, bentuk(c, Color.TRANSPARENT, 12), 12)
        f.contentDescription = deskripsi
        f.isClickable = true
        f.isFocusable = true
        f.setOnClickListener { aksi() }
        return f
    }

    fun garis(c: Context): View {
        val v = View(c)
        v.setBackgroundColor(T.DV)
        return v
    }

    fun bagian(c: Context, s: String): TextView = teks(c, s, 13f, T.T2, true)
}
